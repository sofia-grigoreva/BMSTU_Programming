USE master;
GO

IF DB_ID(N'BeautySalons') IS NOT NULL
BEGIN
    ALTER DATABASE BeautySalons SET SINGLE_USER WITH ROLLBACK IMMEDIATE;
    DROP DATABASE BeautySalons;
    PRINT 'Delete';
END
GO

----------------------------

CREATE DATABASE BeautySalons
ON PRIMARY
(
    NAME = N'BeautySalons_Primary',
    FILENAME = 'C:\SQLData\Lab10\data1.mdf',
    SIZE = 10MB,
    MAXSIZE = 100MB,
    FILEGROWTH = 10%
)
LOG ON
(
    NAME = N'BeautySalons_Log',
    FILENAME = 'C:\SQLData\Lab10\log.ldf',
    SIZE = 5MB,
    MAXSIZE = 25MB,
    FILEGROWTH = 5MB
);
GO


----------------------------

USE BeautySalons;

CREATE TABLE CLIENT
(
    ClientID INT IDENTITY(1,1) PRIMARY KEY,
    PhoneNumber VARCHAR(15) NOT NULL UNIQUE,
    LastName NVARCHAR(25) NOT NULL,
    FirstName NVARCHAR(25) NOT NULL,
    Gender TINYINT NOT NULL DEFAULT 0 CHECK (Gender IN (0, 1)),
);
GO

CREATE TABLE MASTER
(
    MasterID INT IDENTITY(1,1) PRIMARY KEY,
    PhoneNumber VARCHAR(15) NOT NULL UNIQUE,
    LastName NVARCHAR(25) NOT NULL,
    FirstName NVARCHAR(25) NOT NULL,
    Specialization TINYINT NULL,
    SkillLevel TINYINT NULL DEFAULT 3 CHECK (SkillLevel IN (1, 2, 3, 4, 5))
);
GO

CREATE TABLE SERVICE
(
    ServiceID INT IDENTITY(1,1) PRIMARY KEY,
    ServiceName NVARCHAR(50) NOT NULL UNIQUE,
    Price MONEY NOT NULL,
    Duration SMALLINT NOT NULL,
    Category TINYINT NULL,
    Description NVARCHAR(255) NULL
);
GO

CREATE TABLE SALON
(
    SalonID INT IDENTITY(1,1) PRIMARY KEY,
    Address NVARCHAR(100) NOT NULL UNIQUE,
    OpeningHours NVARCHAR(50) NULL,
    PhoneNumber VARCHAR(15) NULL,
    Category TINYINT NULL
);
GO

CREATE TABLE APPOINTMENT
(
    ClientID INT NOT NULL,
    MasterID INT NOT NULL,
    SalonID INT NOT NULL,
    ServiceID INT NOT NULL,
    StartDateTime SMALLDATETIME NOT NULL,
    Status TINYINT NOT NULL DEFAULT 0 CHECK (Status IN (0, 1, 2, 3)),
    Price MONEY NULL,
    Rating TINYINT NULL DEFAULT 0 CHECK (Rating IN (0, 1, 2, 3, 4, 5)),
    PRIMARY KEY (ClientID, MasterID, SalonID, ServiceID, StartDateTime),
    FOREIGN KEY (ClientID) REFERENCES CLIENT(ClientID) ON DELETE CASCADE,
    FOREIGN KEY (MasterID) REFERENCES MASTER(MasterID) ON DELETE CASCADE,
    FOREIGN KEY (SalonID) REFERENCES SALON(SalonID) ON DELETE CASCADE,
    FOREIGN KEY (ServiceID) REFERENCES SERVICE(ServiceID) ON DELETE CASCADE
);
GO

CREATE TABLE MASTER_SERVICE
(
    MasterID INT NOT NULL,
    ServiceID INT NOT NULL,
    PRIMARY KEY (MasterID, ServiceID),
    FOREIGN KEY (MasterID) REFERENCES MASTER(MasterID) ON DELETE CASCADE,
    FOREIGN KEY (ServiceID) REFERENCES SERVICE(ServiceID) ON DELETE CASCADE
);
GO

INSERT INTO CLIENT (PhoneNumber, LastName, FirstName, Gender)
VALUES 
('111', N'Ivanov', N'Ivan', 1),
('112', N'Sidorov', N'Sidor', 0);

INSERT INTO MASTER (PhoneNumber, LastName, FirstName, Specialization, SkillLevel)
VALUES 
('222', N'Petrov', N'Petr', 1, 3);

INSERT INTO SALON (Address, OpeningHours, PhoneNumber)
VALUES 
(N'Central St 10', N'9-18', '333');

INSERT INTO SERVICE (ServiceName, Price, Duration)
VALUES 
(N'Haircut', 500, 40);

INSERT INTO APPOINTMENT (ClientID, MasterID, SalonID, ServiceID, StartDateTime, Status, Price)
VALUES 
(1,1,1,1,'2025-01-01 10:00',0,500),
(2,1,1,1,'2025-01-02 11:00',0,600),
(2,1,1,1,'2025-01-03 12:00',0,700);